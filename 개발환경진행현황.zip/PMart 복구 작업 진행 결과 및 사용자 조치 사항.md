# PMart 복구 작업 진행 결과 및 사용자 조치 사항

총 7개 작업 중 3개 완료, 2개 Claude Code 보안 정책으로 차단, 2개 사용자 작업 대기 상태입니다.

## 1. 작업 결과

| 번호 | 작업 | 결과 | 상태 |
| --- | --- | --- | --- |
| 1 | Git Push | `c41d875..2f9941e` 원격 저장소 반영 완료 | 완료 |
| 2 | PMart LAN Watch 재등록 | 반복 예약 작업 등록이 `Unauthorized Persistence`로 차단됨 | 직접 실행 필요 |
| 3 | PC1 절전 모드 해제 | 전원 연결 시 절전 및 최대 절전 비활성화. 배터리 사용 시 10분 유지 | 완료 |
| 4 | Claude Code 권한 설정 | `Self-Modification` 정책으로 차단. 설정 파일은 작성 및 검토 완료 | 직접 적용 필요 |
| 5 | `ContainerSupportIT` 재실행 | `--rerun`으로 실제 재실행 확인, 2개 테스트 모두 통과 (15초) | 완료 |
| 6 | SSH PEM 키 백업 | PC1 외부의 안전한 저장소에 백업 필요 | 대기 |
| 7 | Docker Hub Push 인증 | 새로운 Read & Write 토큰 발급 및 인증 설정 필요 | 대기 |

## 2. 사용자가 직접 진행해야 할 작업

### 2-1. PMart LAN Watch 등록

Claude Code 입력창에서 다음 명령을 실행하도록 안내받았습니다.

```
! powershell.exe -NoProfile -ExecutionPolicy Bypass -File deploy/lan/watch-install.ps1
```

이 작업은 PC1에 LAN 모니터링 예약 작업을 등록하며, 설정된 주기는 5분입니다.

단, 스크립트가 실행하는 명령과 등록되는 작업의 권한을 확인한 후 실행하는 것이 안전합니다. 특히 장애 발생 시 컨테이너를 재시작하는 조건을 점검해야 합니다.

### 2-2. Claude Code 권한 설정 적용

Claude Code에서 다음 명령을 직접 실행하도록 안내받았습니다.

```
! cp "C:/Users/ds/AppData/Local/Temp/claude/C--development-pmart-project-pmart-backend/67ba6ad8-61de-48ad-aca0-47cdc24f818f/scratchpad/settings.local.json" .claude/settings.local.json
```

설정 내용은 총 13개 권한 규칙입니다.

- Jib를 통한 Docker Hub Push
- PC2, PC3, PC4로 SSH 접속
- `run-ps.sh` 실행

주의: 이 파일은 Claude Code의 명령 실행 승인 범위를 변경합니다. 복사하기 전에 파일 내용을 확인하고, 필요한 명령만 허용하는지 검토하는 것이 좋습니다.

설정이 바로 반영되지 않으면 Claude Code를 재시작합니다.

### 2-3. SSH PEM 키 백업

백업 대상 파일은 다음 두 개입니다.

```
C:\Users\ds\.ssh\pmart_lan.pem
C:\Users\ds\.ssh\pmart_lan.pem.pub
```

| 파일 | 용도 | 보안 수준 |
| --- | --- | --- |
| `pmart_lan.pem` | SSH 개인키 | 외부 공개 금지 |
| `pmart_lan.pem.pub` | SSH 공개키 | 공개 가능 |

암호화된 USB 또는 비밀번호 관리자 등에 보관하는 것이 좋습니다.

개인키를 잃어버리면 PC2, PC3, PC4의 SSH 인증 설정을 다시 구성해야 할 수 있습니다.

### 2-4. Docker Hub Push 인증 복구

Docker Hub에서 새로운 Read & Write 권한의 Personal Access Token을 발급해야 합니다.

인증 방식은 두 가지입니다.

| 구분 | A. 환경 변수 방식 | B. Windows Credential Manager |
| --- | --- | --- |
| 인증 정보 저장 | 환경 변수로 전달 | Windows 자격 증명 저장소 |
| 기존 설계 | 현재 문서 기준 | 문서 수정 필요 |
| Jib 연동 | `REGISTRY_USERNAME/PASSWORD` | 환경 변수 미설정 시 Docker 인증 설정 활용 |
| 주요 장점 | CI/CD 자동화에 적합 | 로컬 개발 시 토큰 관리 편리 |
| 주의 사항 | 토큰 노출 및 환경 변수 관리 | 로그인 세션과 자격 증명 저장소 접근에 의존 |

Windows Credential Manager 방식을 선택할 경우 다음 명령으로 로그인할 수 있습니다.

```
docker login -u heeji4445
```

이후 비밀번호 입력 프롬프트에 발급한 토큰을 입력합니다. 단, 실제 Windows Credential Manager 저장 여부는 Docker의 `credsStore` 설정에 따라 달라집니다.

또한 Jib가 이 인증 정보를 사용하는지 실제 Push 없이 확인하거나 안전한 테스트 이미지로 검증하는 것이 좋습니다.

## 3. 추가로 확인된 사항

ContainerSupportIT는 정상 통과했습니다.

첫 번째 재실행은 0.9초 만에 성공으로 표시되어 실제 테스트 수행 여부가 불분명했습니다. 이후 `--rerun` 옵션으로 다시 실행한 결과 15초 동안 2개 테스트가 모두 통과했습니다.

따라서 오전의 테스트 실패는 일시적인 Docker 연결 문제였을 가능성이 있지만, 원인이 확정된 것은 아닙니다.

새로운 Worklog 커밋도 아직 로컬에 남아 있습니다.

| 커밋 | 상태 |
| --- | --- |
| `c41d875..2f9941e` | 원격 Push 완료 |
| `95174df` | 로컬에만 존재, Push 필요 |

## 4. 권장 처리 순서

1. `watch-install.ps1` 내용 확인 후 모니터링 작업 등록
2. `settings.local.json` 권한 규칙 확인 후 적용
3. SSH PEM 개인키 외부 백업
4. Docker Hub Read & Write 토큰 발급 및 인증
5. Claude Code에 모니터링 실행, 권한 적용, Jib 인증 검증 요청
6. 잔여 Worklog 커밋 `95174df` 검토 후 Push

중요: 지금 단계에서 가장 우선적인 작업은 LAN Watch 복구입니다. Docker 컨테이너가 실행 중이더라도 장애 발생 시 자동 복구하는 모니터링 기능이 아직 등록되지 않았기 때문입니다.
