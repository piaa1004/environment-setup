# 3편. Docker Hub PAT와 SSH를 이용한 원격 Docker 관리

> **학습 목표:** SSH 인증과 Docker Hub 인증을 구별하고, 원격 PC에서 Docker 이미지를 안전하게 받는다.  
> **전제:** 2편의 SSH 접속이 성공했으며 원격 PC에 Docker CLI와 실행 중인 엔진이 있다.

## 1. SSH 키와 Docker PAT는 완전히 다르다

분산 개발 환경에서 다음 두 가지 인증이 필요할 수 있다.

```text
관리 PC ── SSH 공개키 인증 ──► 원격 PC
                               │
                               └── Docker Hub PAT 인증 ──► 이미지 Registry
```

| 인증 정보 | 접근 대상 | 역할 |
|---|---|---|
| SSH 개인키 | 원격 PC의 SSH 서버 | 사용자 신원 증명(전자서명) |
| Docker Hub PAT | Docker Hub Registry | 이미지 조회·다운로드·업로드 권한 확인 |

**PAT(Personal Access Token)는 SSH 개인키가 아니다.** Docker Hub 계정의 비밀번호 대신 사용할 수 있는 인증 토큰이다. 키 인증으로 SSH 접속에 성공해도 Docker Hub에 자동 로그인되는 것은 아니다.

## 2. PAT 권한은 최소화한다

Docker Hub에서 PAT를 생성할 때 목적에 맞는 권한을 선택한다.

| 용도 | 적합한 권한 예시 |
|---|---|
| 공개 이미지만 다운로드 | `Repo Public Read-only` |
| 권한이 있는 비공개 이미지 다운로드 | `Repo Read-only` |
| CI에서 이미지 업로드 | 별도로 관리하는 쓰기 권한 토큰 |

**Pull 전용 PC에 Push/Delete 권한을 줄 필요는 없다.** PAT의 저장소 접근 범위는 계정 접근 권한에 종속되므로, 비공개 이미지 접근 가능 여부도 함께 확인해야 한다.

발급한 토큰의 **실제 문자열은 채팅·저장소·스크린샷에 남기지 않는다.** 토큰 이름만 공유해도 작업 설명에는 충분하다.

## 3. 원격 PC에서 Docker Hub 로그인

원격 PC 화면에서 해당 사용자의 PowerShell을 열고 실행한다.

```powershell
docker version
docker login -u <DOCKER_HUB_ID>
```

`Password:`가 나오면 **계정 비밀번호 대신 PAT를 입력**한다. 입력 문자가 보이지 않는 것은 정상이다. 성공 여부는 `Login Succeeded`로 확인하고, 실제 이미지를 받을 수 있는지도 검사한다.

```powershell
docker pull <이미지저장소>:<태그>
docker image ls
docker compose version
```

`docker compose version`이 실패하면 **Compose 플러그인 설치·경로 문제**를 별도로 점검한다. `docker version`의 Client 정보만 출력되면 엔진까지 정상 연결됐다고 단정할 수 없다. **Server 정보와 `docker ps` 성공**도 확인한다.

> 자동화에서 `docker login --password-stdin`을 사용하면 토큰을 명령행 인자·히스토리에 직접 노출하지 않을 수 있다. 다만 토큰을 읽어오는 방식과 저장 장소 역시 안전해야 하며, 예제 문서에는 실제 토큰을 넣지 않는다.

## 4. SSH 원격 실행과 Docker Context

### 방법 A. SSH로 원격 셸에서 Docker 명령 실행

```powershell
ssh <원격계정>@<원격호스트> 'docker version'
ssh <원격계정>@<원격호스트> 'docker ps'
```

이 방식은 원격 PC가 직접 Docker CLI를 실행한다. Windows SSH 서버의 기본 셸이 CMD인지 PowerShell인지, Docker Desktop이 사용자 로그인 후 실행 중인지에 따라 결과가 달라질 수 있다.

### 방법 B. Docker Context로 원격 엔진 지정

```powershell
docker context create worker-a --docker 'host=ssh://<원격계정>@<원격호스트>'
docker --context worker-a info
```

이 방식은 **관리 PC의 Docker CLI가 SSH를 통해 원격 Docker Engine API에 접근**한다. 공식적으로 지원하는 원격 엔진 방식이지만, **Windows OpenSSH + Docker Desktop 조합에서는 추가 호환성 검증이 필요**하다. `context create`가 성공해도 `info`가 실패할 수 있으므로 실제 테스트한다.

SSH를 통해 Docker 명령을 실행하는 방식과 Context 방식은 서로 대체 가능한 상황도 있지만 동작 구조가 다르다. 문제 해결 시 둘을 혼동하지 않는다.

## 5. SSH 세션에서 `docker login`이 실패할 때

Windows Docker Desktop은 자격 증명을 운영체제의 **Credential Manager 등 자격 증명 저장소**에 보관할 수 있다. 원격 SSH 로그인 세션에서는 사용자 세션·자격 증명 저장소 접근 방식에 따라 아래와 같은 오류가 날 수 있다.

```text
A specified logon session does not exist.
```

이 오류가 발생해도 SSH 자체가 실패한 것은 아니다. 먼저 같은 계정으로 **PC 화면에서 Docker 로그인이 되는지**, 원격 SSH 세션에서 `docker version`과 `docker ps`가 되는지 구분해서 확인한다.

설정 파일에 토큰을 직접 저장하는 우회 방법도 있지만 **최후의 수단**으로 취급한다. Docker의 `config.json`에 들어가는 Base64 인증 정보는 **암호화가 아니며**, 파일 읽기 권한이 있으면 복원할 수 있다. 필요하다면 최소 권한의 Pull 토큰, 엄격한 파일 ACL, 만료·교체 정책을 적용해야 한다. 일반적으로는 지원되는 자격 증명 저장소를 우선 사용한다.

또한 Docker Desktop의 **로그인 시 자동 시작**과 Windows의 **부팅 시 SSH 자동 시작**은 다르다. SSH 접속이 되더라도 로그인하지 않은 PC에서 Docker 엔진이 실행되지 않을 수 있다.

## 6. 분산 실행에서 주의할 점

- **IP 관리:** 공유기 DHCP 예약으로 주소 변경을 줄일 수 있다. DNS 없이 임의 호스트 이름을 사용하려면 별도의 이름→주소 해석 설정이 필요하다.
- **컨테이너 이름:** PC가 다른 Docker 엔진에 있으면 Compose 서비스 이름이 자동으로 서로 해석되지 않는다. 서비스 URL·포트·방화벽·DNS 또는 `extra_hosts`를 별도로 설계한다.
- **Compose:** 한 PC에서 `docker compose up`에 성공했다고 여러 PC의 컨테이너가 하나의 Docker 네트워크에 자동 연결되는 것은 아니다.
- **보안:** Docker Engine 제어 권한은 사실상 매우 강력한 시스템 권한이다. SSH 계정과 Docker 접근 권한을 최소화한다.

## 7. PAT가 유출되었다면

1. Docker Hub에서 해당 토큰을 **폐기 또는 비활성화**한다.
2. 필요한 경우 새 토큰을 **최소 권한으로 재발급**한다.
3. 사용하는 PC의 Docker 인증 정보를 새 토큰으로 교체한다.
4. 토큰이 노출된 로그·문서·저장소를 점검하고, 비공개 이미지 접근 여부를 확인한다.

`docker logout`은 로컬 로그인 정보를 제거하는 동작이며, **토큰 자체를 폐기하는 동작은 아니다.** 실제 악용 여부는 별도 증거 없이 단정하지 않는다.

## 8. 핵심 정리

- **SSH 키는 PC 접속용**, **Docker PAT는 Registry 인증용**이다.
- 권한이 필요하지 않으면 토큰을 만들지 말고, 필요하다면 최소 권한을 준다.
- 검증은 **SSH 로그인 → Docker 엔진 연결 → Docker Hub 로그인 → 이미지 Pull** 순서로 분리한다.
- Docker Context와 Windows Docker Desktop은 **실제 연결 테스트**로 호환성을 확인한다.

### 공식 참고 자료

- [Docker Docs — Access tokens](https://docs.docker.com/security/access-tokens/)
- [Docker Docs — Access token permissions](https://docs.docker.com/security/access-tokens/reference/)
- [Docker Docs — docker login / 자격 증명 저장](https://docs.docker.com/reference/cli/docker/login/)
- [Docker Docs — SSH를 통한 원격 Docker Engine 연결](https://docs.docker.com/engine/security/protect-access/)
