# B마트(PMart) LAN·SSH·Docker 기반 인프라 및 배포 구성

## 1. 개요

B마트(PMart) 프로젝트는 **4대의 Windows 물리 PC를 동일 LAN에 연결**하고, **PC1에서 SSH로 PC2·PC3·PC4를 원격 관리**하는 멀티 호스트 실행 환경으로 구성한다. Java 마이크로서비스는 컨테이너 이미지로 빌드하여 Docker Hub에 업로드하고, 대상 PC가 해당 이미지를 다운로드한 후 Docker Compose로 실행한다.

핵심적으로 **SSH는 원격 명령 전달**, **Docker Hub는 이미지 보관·전달**, **Docker Compose는 대상 PC의 컨테이너 실행 설정**을 담당한다. 이 구성 자체를 Kubernetes나 Docker Swarm 클러스터로 부르지는 않는다.

## 2. PC별 역할

| 구분 | 주요 역할 | 관련 구성요소 |
|---|---|---|
| PC1 | 개발·빌드·배포·원격 관리 | Claude Code, Git, Gradle Jib, SSH Client |
| PC2 | 백엔드 실행 및 이벤트 메시징 | 마이크로서비스, Kafka |
| PC3 | 데이터 및 변경 데이터 캡처 | PostgreSQL, Debezium Connect |
| PC4 | API 진입점·인증 및 백엔드 실행 | API Gateway, Auth Service, Redis, Zipkin, 마이크로서비스 |

> 위 구성은 현재까지 공유된 프로젝트 설명을 바탕으로 정리했다. 서비스별 정확한 배치와 모든 실제 경로는 최신 배포 설정에서 재확인이 필요하다.

### 네트워크

- PC1~PC4는 동일한 사설 LAN에서 통신한다.
- 기존에 언급된 PC2 IP는 `192.168.0.34`, PC3 IP는 `192.168.0.222`이다.
- PC1·PC4의 실제 IP는 최신 `ipconfig` 또는 SSH 설정 파일에서 확인한다.
- SSH 접속에는 일반적으로 TCP 22번 포트를 사용한다. 방화벽에서 접근이 허용되어야 한다.

## 3. 전체 아키텍처 및 배포 흐름

```mermaid
flowchart TB
    A[PC1: 개발·빌드·배포 관리]
    H[(Docker Hub: 이미지 레지스트리)]
    B[PC2: 서비스·Kafka]
    C[PC3: DB·Debezium]
    D[PC4: Gateway·Auth·서비스]

    A -->|Jib 빌드 후 이미지 Push| H
    A -.->|LAN + SSH: 원격 명령| B
    A -.->|LAN + SSH: 원격 명령| C
    A -.->|LAN + SSH: 원격 명령| D
    H -->|필요한 이미지 Pull| B
    H -->|필요한 이미지 Pull| C
    H -->|필요한 이미지 Pull| D
```

배포 과정은 다음 순서로 이해하면 된다.

1. **PC1에서 개발 및 빌드:** Java 서비스를 수정·테스트하고 Gradle Jib로 컨테이너 이미지를 생성한다.
2. **Docker Hub에 Push:** 빌드한 이미지를 레지스트리에 업로드한다.
3. **SSH로 원격 명령 전달:** PC1이 대상 PC에 SSH 접속해 배포 명령을 실행한다.
4. **대상 PC에서 Pull:** PC2~PC4는 필요한 이미지를 Docker Hub에서 직접 다운로드한다.
5. **Docker Compose 실행:** 대상 PC의 Compose 설정을 사용해 컨테이너를 시작하거나 갱신한다.

**주의:** SSH가 Docker 이미지를 직접 전송하는 것이 아니다. SSH는 원격 실행 명령을 전달하고, 실제 이미지 다운로드는 대상 PC의 Docker가 수행한다.

## 4. LAN과 SSH의 관계

LAN은 PC 간 네트워크 연결을 제공하며 SSH(Secure Shell)는 그 네트워크 위에서 암호화된 원격 접속과 명령 실행을 제공한다.

### SSH 원격 명령 실행 순서

1. PC1(SSH Client)이 원격 PC에 접속을 요청한다.
2. PC1은 자신의 SSH 개인키를 이용해 키 보유 사실을 증명하고, 원격 PC(SSH Server)는 등록된 공개키로 인증을 검증한다.
3. 인증에 성공하면 원격 PC가 전달받은 명령을 실행한다.
4. 실행 결과가 SSH 연결을 통해 PC1 터미널로 반환된다.

예시:

```bash
ssh pmart-pc2 "docker ps"
```

이 명령은 PC2에서 `docker ps`를 실행하고 그 출력을 PC1에서 보여준다.

## 5. SSH 키와 관련 설정 파일

### PC1의 SSH 파일

예를 들어 PC1 Windows 계정이 `ds`라면 다음과 같은 경로를 사용할 수 있다.

```text
C:\Users\ds\.ssh\
├── config           # SSH 서버별 접속 설정
├── pmart_lan        # PC1의 SSH 사용자 개인키
├── pmart_lan.pub    # PC1의 SSH 사용자 공개키
└── known_hosts      # 접속한 원격 서버의 호스트 키 기록
```

- 개인키 `pmart_lan`은 유출하지 말고 PC1에 안전하게 보관한다.
- `pmart_lan.pub`의 공개키 내용을 원격 서버의 인증 허용 목록에 등록한다.
- `known_hosts`는 **서버의 호스트 신원 확인용**으로, 사용자 인증용 공개키 저장 파일과는 역할이 다르다.

### PC2~PC4의 공개키 등록 위치

Windows OpenSSH에서 **관리자 계정으로 접속하는 구성**이라면 통상 다음 경로를 사용한다.

```text
C:\ProgramData\ssh\administrators_authorized_keys
```

**일반 사용자 계정**으로 접속한다면 보통 다음 경로다.

```text
C:\Users\<원격로그인계정>\.ssh\authorized_keys
```

원격 PC에는 `pmart_lan.pub` 파일 자체가 존재할 필요는 없고, 그 안의 공개키 내용이 허용 목록에 등록되어 있으면 된다. 별도로 각 SSH 서버는 자신만의 서버 호스트 키도 가진다.

### SSH config 예시

PC1의 `C:\Users\ds\.ssh\config`:

```sshconfig
Host pmart-pc2
    HostName 192.168.0.34
    User ds
    IdentityFile ~/.ssh/pmart_lan

Host pmart-pc3
    HostName 192.168.0.222
    User ds
    IdentityFile ~/.ssh/pmart_lan
```

위 `User ds`는 예시다. **실제 원격 PC에 존재하는 로그인 계정**으로 설정해야 한다. `pmart-pc2` 같은 별칭은 SSH 설정에 정의된 이름이지 반드시 DNS나 `hosts` 파일에 등록된 호스트명은 아니다.

## 6. `/etc/hosts`, Windows hosts, `.ssh/config` 차이

| 기능 | Linux | Windows |
|---|---|---|
| 이름과 IP 매핑 | `/etc/hosts` | `C:\Windows\System32\drivers\etc\hosts` |
| SSH 접속 설정 | `~/.ssh/config` | `C:\Users\ds\.ssh\config` (사용자별 경로) |
| SSH 키 저장 | `~/.ssh/` | `C:\Users\ds\.ssh\` (사용자별 경로) |

- **hosts 파일:** `pc2 → 192.168.0.34`처럼 일반 호스트명 해석에 사용한다.
- **SSH config:** `pmart-pc2`에 접속할 IP·계정·개인키 등을 SSH 전용으로 지정한다.

## 7. Docker Hub와 SSH 인증은 별개

| 항목 | SSH | Docker Hub |
|---|---|---|
| 사용 목적 | PC 간 원격 접속 및 명령 실행 | 컨테이너 이미지 Push/Pull |
| 주된 인증 수단 | SSH 개인키·공개키 | Docker 로그인 토큰/PAT 등 |
| 설정 위치 | `.ssh` 폴더 | Docker CLI 설정 폴더 |
| 통신 경로 | 주로 사설 LAN | 보통 인터넷 |

따라서 Docker Hub 로그인 정보를 SSH 공개키 파일에 저장하거나, Docker Hub의 자격 증명으로 SSH 서버에 로그인하는 것은 아니다.

## 8. `.docker-pmart` 폴더를 사용한 이유

프로젝트에서 논의된 우회 방식은 SSH 키 폴더를 옮기는 것이 아니라, **원격 Windows SSH 세션에서 Docker Hub 인증 시 발생할 수 있는 Windows Credential Manager 접근 문제를 피하기 위해 Docker CLI 설정을 별도 폴더로 관리하는 방식**이다.

예시 명령:

```powershell
docker.exe --config "$env:USERPROFILE\.docker-pmart" login
```

| 구성요소 | 의미 |
|---|---|
| `docker.exe` | Docker CLI 실행 |
| `--config` | 사용할 Docker CLI 설정 디렉터리 지정 |
| `$env:USERPROFILE` | 현재 PowerShell 사용자의 홈 폴더 경로 |
| `\.docker-pmart` | 별도 설정 디렉터리 이름 |
| `login` | Docker 레지스트리 로그인 |

현재 사용자의 홈 폴더가 `C:\Users\ds`라면 경로는 `C:\Users\ds\.docker-pmart`가 된다. 일반적으로 해당 폴더에 `config.json`이 사용된다.

> **보안상 유의:** 설정 폴더만 변경한다고 Credential Manager 접근 문제가 반드시 해결되지는 않는다. `config.json`의 `credsStore`/`credHelpers` 등 실제 인증 저장 설정에 따라 동작이 달라진다. 인증 토큰이 파일에 저장될 수도 있으므로 파일 접근 권한을 제한하고 저장소에 커밋하지 않아야 한다.

## 9. 환경변수와 PEM 파일의 차이

### 환경변수는 비밀번호 전용이 아니다

PowerShell 예시:

```powershell
$env:USERPROFILE
```

이는 현재 사용자 홈 디렉터리를 가져오는 일반 환경변수다.

반면 애플리케이션 비밀키를 전달하는 방식에는 다음 차이가 있다.

**A. 환경변수에 개인키 내용 자체 저장(개념 예시)**

```powershell
$env:PRIVATE_KEY = "-----BEGIN PRIVATE KEY-----..."
```

**B. 개인키 파일 경로만 환경변수로 전달(개념 예시)**

```powershell
$env:PRIVATE_KEY_FILE = "C:\keys\private.pem"
```

B에서는 환경변수가 사용되더라도 실제 키 값은 PEM 파일에 저장된다. 따라서 **PEM 파일 방식으로 변경했다는 사실과 `$env:` 문법을 사용하는 것은 모순되지 않는다.**

### 서로 구별해야 할 인증 정보

| 인증 대상 | 역할 | 비고 |
|---|---|---|
| SSH 사용자 개인키 | PC1의 원격 서버 접속 증명 | `pmart_lan` 등 |
| Auth Service JWT 서명키 | JWT 토큰 서명 | PEM 형식 등 가능; SSH 키와 다른 용도 |
| Docker Hub 자격 증명 | 이미지 레지스트리 로그인 | PAT/토큰 등 |
| 서비스 간 Client Secret | 서비스 자격 증명 | 별도 비밀 정보 |

> JWT 서명용 PEM 파일의 실제 적용 경로와 기존 `PMART_AUTH_SIGNING_KEYS_*`, `PMART_SERVICE_CLIENT_SECRET`, `REGISTRY_USERNAME`/`REGISTRY_PASSWORD` 같은 설정이 현재 어떻게 사용되는지는 최신 코드·Compose·배포 스크립트를 확인해야 확정할 수 있다.

## 10. Docker Compose의 역할과 경로

Docker Compose는 대상 PC에서 **어떤 컨테이너를 어떤 이미지·환경설정·포트·볼륨으로 실행할지** 정의하는 도구다. Docker Hub처럼 이미지를 보관하거나 SSH처럼 원격 로그인하는 도구가 아니다.

기존 대화에서 언급한 경로 예시는 다음과 같다.

```text
%USERPROFILE%\pmart-lan\compose.yml
```

이는 대상 Windows 사용자의 홈 폴더 아래 `pmart-lan\compose.yml`이라는 의미다. 실제 파일의 존재 여부는 PC별 확인이 필요하다.

PC1 프로젝트의 `deploy/lan/`은 **프로젝트 루트 기준 상대 경로**다. 전체 경로는 실제 프로젝트가 어디에 체크아웃되어 있는지에 따라 달라진다.

## 11. 경로 비교표

| 경로 | 사용 목적 |
|---|---|
| `C:\Users\ds\.ssh\` | PC1 SSH 인증키 및 접속 설정(예시 사용자 `ds`) |
| `C:\Users\ds\.ssh\config` | SSH 대상 PC별 IP·계정·키 지정 |
| `C:\Users\ds\.ssh\pmart_lan` | PC1 SSH 사용자 개인키 |
| `C:\Users\ds\.ssh\pmart_lan.pub` | 해당 SSH 공개키 |
| `C:\Users\ds\.ssh\known_hosts` | 원격 SSH 서버의 호스트 키 기억 |
| `%USERPROFILE%\.docker\` | Docker CLI 기본 설정 폴더 |
| `%USERPROFILE%\.docker-pmart\` | 별도 Docker CLI 설정·인증 폴더 |
| `%USERPROFILE%\pmart-lan\compose.yml` | 대상 PC Compose 배포 파일로 언급된 경로(확인 필요) |
| `프로젝트루트\deploy\lan\` | PC1 프로젝트의 LAN 배포 설정·스크립트 위치 |
| `C:\Windows\System32\drivers\etc\hosts` | Windows 호스트명-IP 매핑 |
| `C:\ProgramData\ssh\administrators_authorized_keys` | 관리자 계정 SSH 공개키 허용 목록 |

## 12. 용어 정리

- **LAN:** 여러 PC를 연결하는 로컬 네트워크.
- **SSH:** 암호화된 원격 접속·명령 실행 프로토콜.
- **SSH 개인키·공개키:** 원격 접속의 키 기반 사용자 인증 수단.
- **Docker Hub:** 빌드된 컨테이너 이미지를 저장·배포하는 레지스트리.
- **Docker CLI 설정 폴더:** Docker 로그인 및 CLI 동작 설정을 보관하는 위치.
- **PEM:** 키·인증서를 표현하는 인코딩 형식. PEM이라는 확장자만으로 키의 용도가 결정되지는 않는다.
- **환경변수:** 프로세스에 설정값·경로·비밀값 등을 전달하는 수단.
- **Docker Compose:** 여러 컨테이너의 실행 구성을 정의하고 관리하는 도구.
- **멀티 호스트 기반 역할별 워크로드 분리:** 여러 물리 PC에 서로 다른 실행 역할을 배치한 인프라 구조.

## 13. 최종 요약

**LAN으로 PC1~PC4를 연결 → PC1이 SSH로 원격 명령 전달 → PC1이 Docker Hub에 이미지를 Push → 대상 PC가 이미지를 Pull → Docker Compose로 컨테이너 실행**하는 구조다.

`.ssh`는 SSH 인증·접속 설정, `.docker-pmart`는 Docker CLI 인증·설정, PEM 파일은 별도 용도의 키 저장 방식이다. `$env:USERPROFILE`처럼 환경변수를 사용한다는 이유만으로 비밀키를 환경변수에 저장한다고 판단해서는 안 된다.
