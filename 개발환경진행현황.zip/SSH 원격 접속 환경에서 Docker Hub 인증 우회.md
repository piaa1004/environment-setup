# SSH 원격 접속 환경에서 Docker Hub 인증 우회

## 1. 인증 정보 두가지

| 구분 | 용도 | 관련 파일 |
| --- | --- | --- |
| SSH 인증 | PC1에서 PC2\~PC4 원격 접속 | `pmart_lan`, `pmart_lan.pub` |
| Docker Hub 인증 | Docker 이미지 Push/Pull | Docker 로그인 정보, PAT |

## 2. 발생한 오류

```
A specified logon session does not exist
```

원인은 SSH로 접속한 Windows 세션에서 Windows Credential Manager(자격 증명 관리자)에 정상적으로 접근하지 못한 것.

그래서 Docker Hub 인증 정보를 기본 설정 대신 별도 폴더에 저장하도록 변경했음.

### 실제 적용한 구성

| 구분 | 경로 | 목적 |
| --- | --- | --- |
| SSH 인증키 | `C:\Users\ds\.ssh\` (PC1) | PC2\~PC4 원격 접속 |
| Docker 기본 설정 | `%USERPROFILE%\.docker\` | 일반 Docker 설정 및 인증 |
| Docker 별도 설정 | `%USERPROFILE%\.docker-pmart\` (원격 PC) | SSH 세션에서 사용할 Docker Hub 인증 |

### 우회 방법

PC2·PC3에서 별도 Docker 설정 폴더를 사용해 로그인하도록 구성했다. (Docker Hub에 로그인하는 명령어)

```
docker.exe --config "$env:USERPROFILE\.docker-pmart" login
```

| 명령어 | 의미 |
| --- | --- |
| `docker.exe` | Docker CLI 실행 |
| `--config` | Docker 설정 폴더 지정 |
| `$env:USERPROFILE` | 현재 Windows 사용자 홈 폴더 경로 |
| `\.docker-pmart` | 별도로 사용하는 Docker 설정 폴더 |
| `login` | Docker Hub 로그인 |

이렇게 하면 Docker Hub 인증 정보를 별도 `config.json`에 저장할 수 있다.

추가로 별도 설정 경로를 사용하면서 Docker Compose 플러그인 검색 경로가 누락되는 문제가 발생해 `cliPluginsExtraDirs` 설정도 추가했음.

결론: SSH 원격 세션에서 Docker Hub 로그인이 실패하자 Docker 인증 설정을 `.docker-pmart` 폴더로 분리한 것.
