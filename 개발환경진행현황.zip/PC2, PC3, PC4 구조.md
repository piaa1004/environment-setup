# PC2, PC3, PC4 구조

## 1. Windows 자격 증명 관리자(Credential Manager) 사용 이력

확인된 기록에서는 Docker와 관련된 3건의 사용 이력이 있으며, GitHub 및 SSH 키에 Credential Manager를 사용했다는 기록은 없습니다.

| 날짜 및 시간 | 대상 PC | 발생 내용 | 의도적 사용 여부 |
| --- | --- | --- | --- |
| 10/23 19:00 | PC1 | Docker Desktop 기본 설정인 `credsStore: desktop`으로 인해 Docker Hub의 빈 인증 정보가 자격 증명 관리자에 저장되어 있었음. Jib가 빈 인증 정보로 이미지 다운로드를 시도하여 `401 Unauthorized` 오류 발생. 설정을 변경하지 않고 기본 이미지 저장소를 `gcr.io`로 변경하여 해결 | 아니요. 기본 설정에 따른 부수적 사용 |
| 10/24 14:50 | PC1 | 읽기 전용 Docker Hub 토큰 `pmart-runtime-pull`을 사용하여 `docker login` 실행. `credsStore: desktop` 설정으로 인해 Credential Manager에 저장되었을 가능성이 높지만, 실제 저장 여부는 기록에 명시되지 않음 | 로그인은 의도적이었으나 저장 방식은 기본 설정 |
| 10/24 14:50 이후 | PC2, PC3, PC4 | SSH 원격 접속에서 `docker login` 실행 시 자격 증명 관리자에 접근하지 못해 로그인 세션 오류 발생. 별도 Docker 설정 디렉터리를 사용하여 토큰을 파일에 저장하는 방식으로 우회 | Credential Manager 사용을 회피 |

### 2. 관련 인증 정보별 사용 방식

| 인증 정보 | Credential Manager 사용 여부 | 실제 사용 또는 저장 방식 |
| --- | --- | --- |
| Docker Hub 인증 (PC1) | 사용 가능성 높음 | Docker Desktop의 `credsStore: desktop` |
| Docker Hub 인증 (PC2\~PC4) | 사용하지 않음 | 별도 Docker 설정 파일에 저장 |
| GitHub Push 인증 | 확인되지 않음 | Git Credential Manager 사용 가능성은 있으나 기록 없음 |
| SSH 공개키 및 개인키 | 사용 기록 없음 | SSH 키 기반 인증 |
| Docker Hub Push 토큰 (`pmart-ci-push`) | 사용하지 않음 | 환경 변수 `REGISTRY_USERNAME/PASSWORD` |
| Docker Hub Pull 토큰 (`pmart-runtime-pull`) | PC1은 사용 가능성 높음 | PC1은 Docker 기본 인증 저장소, PC2\~PC4는 별도 설정 파일 |
| Sysinternals Autologon | 사용하지 않음 | 도입 제안만 있었으며 실제 설정되지 않음. Credential Manager가 아닌 LSA 기반 암호화 방식 |

## 3. PC2\~PC4에서 발생한 문제와 해결 방식

문제 원인

SSH 원격 접속 세션에서는 Windows Credential Manager에 접근하지 못하는 상황이 발생했습니다.

오류 메시지:

```
A specified logon session does not exist
```

적용된 해결 방법

Docker의 기본 인증 저장소 대신 별도의 설정 디렉터리를 사용했습니다.

```
docker.exe --config %USERPROFILE%\.docker-pmart login
```

이 방식은 해당 디렉터리의 `config.json`에 인증 정보를 저장하도록 구성할 수 있습니다.

- 저장 대상: Docker Hub 읽기 전용 토큰
- 저장 방식: 파일에 Base64 인코딩된 인증 정보
- 보안 특성: Base64는 암호화가 아니므로 파일 접근 권한 관리 필요
- 사용 목적: SSH 원격 환경에서 Docker 이미지 Pull 인증

## 4. PC1 포맷 이후 상태

| 항목 | 현재 상태 |
| --- | --- |
| PC1 기존 Credential Manager 정보 | 포맷으로 삭제된 것으로 판단 |
| PC1 기존 Docker 인증 정보 | 삭제된 것으로 판단 |
| 현재 `~/.docker/config.json`의 `auths` | 비어 있다고 보고됨 |
| GitHub 인증 정보 | 기존 정보의 복원 여부 확인되지 않음 |
| PC2\~PC4 Docker 인증 정보 | PC1 포맷과 별개이므로 각 PC에서 확인 필요 |

## 5. 최종 정리

핵심은 Credential Manager를 명시적으로 사용하도록 설계한 것이 아니라, Docker Desktop의 기본 설정으로 인해 사용되었다는 점입니다.

1. PC1에서는 Docker Desktop 기본 설정에 의해 Credential Manager가 사용되었을 가능성이 높습니다.
2. PC2\~PC4에서는 SSH 세션의 Credential Manager 접근 오류 때문에 별도 파일 저장 방식으로 변경했습니다.
3. GitHub 인증이나 SSH 키가 Credential Manager에 저장되었다는 근거는 없습니다.
4. Docker Hub Push 토큰은 환경 변수로 전달되었습니다.
5. PC1 포맷으로 기존 로컬 인증 정보는 삭제된 것으로 판단되지만, PC2\~PC4의 인증 정보는 별도로 관리해야 합니다.

주의: PC1이 포맷되었다고 해서 Docker Hub에 발급된 토큰 자체가 폐기되는 것은 아닙니다. 기존 토큰은 Docker Hub에서 별도로 폐기하지 않았다면 여전히 유효할 수 있습니다.
