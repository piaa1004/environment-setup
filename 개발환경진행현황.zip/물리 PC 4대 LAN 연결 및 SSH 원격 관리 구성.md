# 물리 PC 4대 LAN 연결 및 SSH 원격 관리 구성

## 1. 구성 개요

B마트 프로젝트는 4대의 Windows 물리 PC를 동일한 LAN(Local Area Network)에 연결하고, SSH를 이용하여 PC1에서 PC2·PC3·PC4를 원격으로 관리하는 구조로 구성하였다.

- LAN: PC 간 네트워크 통신 환경 제공
- SSH: 원격 접속 및 명령어 실행
- SSH 공개키 인증: 비밀번호 입력 없이 안전하게 원격 접속
- PC1: 중앙 개발·배포·관리 PC
- PC2·PC3·PC4: 원격 관리 대상 서버

## 2. LAN 네트워크 구성

공유기 / LAN — 192.168.0.x 대역

PC1 , PC2(192.168.0.34), PC3(192.168.0.222), PC4(\~)

동일한 LAN에 연결된 PC들은 사설 IP 주소를 통해 통신할 수 있다. 단, 같은 LAN이어도 Windows 방화벽이나 네트워크 설정에 따라 접속이 차단될 수 있다. → **방화벽 해제** 혹은 별도의 인바운드 규칙을 허용해야하는 이유

### PC별 IP 확인

Windows CMD 또는 PowerShell에서 실행한다.

```
ipconfig
```

출력된 `IPv4 주소`를 확인하면 된다.

## 3. SSH 원격 접속 구성

SSH(Secure Shell)는 네트워크를 통해 다른 PC에 암호화된 연결을 설정하고 명령어를 실행하는 프로토콜이다.

B마트 프로젝트에서는 다음과 같이 구성하였다.

| 구분 | PC1 | PC2·PC3·PC4 |
| --- | --- | --- |
| SSH 역할 | Client | Server |
| Windows OpenSSH | Client | Server |
| SSH 개인키 | 보관 | PC1의 개인키는 불필요 |
| SSH 공개키 | 생성·보관 | 인증 허용 목록에 등록 |
| SSH 접속 방향 | 접속 요청 | 요청 수신 |
| 주요 목적 | 원격 명령 실행 | 원격 명령 처리 |

### 3.1 SSH 키 생성

PC1에서 SSH 키 쌍을 생성한다.

```
ssh-keygen -t ed25519 -f "$env:USERPROFILE\.ssh\pmart_lan"
```

생성되는 파일은 다음과 같다.

```
C:\Users\ds\.ssh\
├── pmart_lan          # SSH 개인키
└── pmart_lan.pub      # SSH 공개키
```

- `pmart_lan`: PC1에만 보관하는 사용자 인증 개인키
- `pmart_lan.pub`: PC2·PC3·PC4에 등록하는 공개키 (지금은 pem 파일로 바꿈)

개인키를 원격 서버에 복사할 필요는 없다.

### 3.2 PC2·PC3·PC4에 공개키 등록

Windows OpenSSH Server를 활성화하고, PC1에서 생성한 공개키를 원격 PC의 인증 허용 목록에 등록한다.

Windows 관리자 계정으로 접속하는 경우:

```
C:\ProgramData\ssh\administrators_authorized_keys
```

일반 사용자 계정으로 접속하는 경우:

```
C:\Users\<계정명>\.ssh\authorized_keys
```

이 파일에는 `pmart_lan.pub`의 공개키 내용을 등록한다.

또한 원격 PC의 Windows 방화벽에서 SSH 접속용 TCP 22번 포트를 허용해야 한다.

## 4. SSH 접속 설정 파일

PC1의 SSH 설정 파일 경로는 다음과 같다.

```
C:\Users\ds\.ssh\config
```

예시:

```
Host pmart-pc2
    HostName 192.168.0.34
    User ds
    IdentityFile ~/.ssh/pmart_lan

Host pmart-pc3
    HostName 192.168.0.222
    User ds
    IdentityFile ~/.ssh/pmart_lan

Host pmart-pc4
    HostName <PC4의 IP 주소>
    User ds
    IdentityFile ~/.ssh/pmart_lan
```

`User ds`는 예시이며 실제 원격 PC에 존재하는 SSH 로그인 계정으로 설정해야 한다.

| 설정 | 설명 |
| --- | --- |
| `Host` | SSH 접속에 사용하는 별칭 |
| `HostName` | 원격 PC의 실제 IP 주소 |
| `User` | 원격 Windows 로그인 계정 |
| `IdentityFile` | SSH 인증에 사용할 개인키 경로 |

이렇게 설정하면 IP 주소와 사용자 계정을 매번 입력하지 않아도 된다.

## 5. SSH 원격 접속 및 명령 실행

### 5.1 원격 PC 접속

PC1에서 실행한다.

```
ssh pmart-pc2
```

PC2에 접속하여 원격 명령어를 실행할 수 있다.

### 5.2 SSH를 통한 원격 명령 실행

원격 PC에서 Docker 컨테이너 상태 확인:

```
ssh pmart-pc2 "docker ps"
```

PC3의 컴퓨터 이름 확인:

```
ssh pmart-pc3 "hostname"
```

원격 명령 실행 과정은 다음과 같다.(`ssh pmart-pc2 "docker ps"`)

1. PC1 (SSH Client)  
PC2·PC3·PC4에 SSH 접속을 요청하고 개인키를 이용해 인증한다. + 원격 명령 요청
2. PC2·PC3·PC4 (SSH Server)  
등록된 공개키로 인증을 확인하고, PC1이 요청한 명령어를 실행한다. (LAN / SSH 암호화 통신)
3. 명령어 실행 결과 반환  
원격 PC에서 명령어를 실행한 결과를 암호화된 SSH 연결을 통해 PC1으로 전달한다.
4. PC1에서 결과 확인  
PC1의 터미널에서 원격 명령어의 실행 결과를 확인한다.

## 6. 주요 파일 경로 정리

| 경로 | 역할 |
| --- | --- |
| `C:\Users\ds\.ssh\` | PC1 SSH 설정 및 인증키 폴더 |
| `C:\Users\ds\.ssh\config` | SSH 접속 별칭 및 서버 설정 |
| `C:\Users\ds\.ssh\pmart_lan` | SSH 개인키 |
| `C:\Users\ds\.ssh\pmart_lan.pub` | SSH 공개키 |
| `C:\Users\ds\.ssh\known_hosts` | 접속한 서버의 호스트 키 기록 |
| `C:\ProgramData\ssh\administrators_authorized_keys` | 원격 Windows 관리자 계정의 공개키 인증 목록 |
| `C:\Windows\System32\drivers\etc\hosts` | Windows 호스트 이름과 IP 주소 매핑 |

→ SSH 파일 형식 pem 파일로 바뀜
