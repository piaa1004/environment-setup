# 2편. Windows에서 SSH 비대칭키 생성과 원격 접속 실습

> **학습 목표:** Windows PC 두 대 사이에서 **Ed25519 공개키 인증으로 SSH 접속**한다.  
> **준비:** 관리자 권한으로 설정할 수 있는 원격 PC, Windows PowerShell, OpenSSH  
> 모든 주소·계정·키 이름은 **실습용 자리표시자**이며 실제 값으로 변경해야 한다.

## 1. 작업 흐름

```text
[접속할 PC]                     [접속받을 PC]
Ed25519 개인키 생성              OpenSSH 서버 실행
      │                              │
      └── 공개키만 등록 ────────────► authorized_keys
      │                              │
      └── ssh 연결 요청 ────────────► 공개키로 서명 검증
                                     ↓
                                 원격 로그인
```

## 2. 원격 PC: OpenSSH 서버 준비

**원격 PC에서 관리자 권한 PowerShell**을 실행한다.

```powershell
# 설치 상태 확인
Get-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0

# NotPresent일 때만 설치
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0

# 서버를 실행하고 자동 시작 설정
Set-Service sshd -StartupType Automatic
Start-Service sshd
Get-Service sshd | Select-Object Name, Status, StartType
```

`Running`, `Automatic`인지 확인한다. 이후 SSH 방화벽 규칙을 확인한다.

```powershell
Get-NetFirewallRule -Name OpenSSH-Server-In-TCP -ErrorAction SilentlyContinue |
  Select-Object Name, Enabled, Direction, Action

Get-NetFirewallRule -Name OpenSSH-Server-In-TCP -ErrorAction SilentlyContinue |
  Get-NetFirewallAddressFilter | Select-Object RemoteAddress
```

서버 설치 시 넓은 범위에서 22번 포트를 허용하는 규칙이 생성될 수 있다. **실습에 필요한 관리 PC만 접근하도록 기존 규칙의 범위를 검토**한다. 다른 규칙을 추가하는 것만으로 기존 허용 범위가 좁아지지는 않는다.

클라이언트 PC에서 확인:

```powershell
Test-NetConnection <원격_PC_주소> -Port 22
```

`TcpTestSucceeded : True`는 **포트 연결 성공**을 뜻하며, SSH 로그인 성공은 아니다.

## 3. 접속할 PC: 키 쌍 생성

```powershell
New-Item -ItemType Directory -Force "$HOME\.ssh" | Out-Null

ssh-keygen -t ed25519 -a 100 -f "$HOME\.ssh\study_ed25519" -C "study-client"
```

생성되는 파일은 두 개다.

| 파일 | 역할 |
|---|---|
| `study_ed25519` | **개인키**. 접속 PC에만 보관 |
| `study_ed25519.pub` | **공개키**. 원격 PC에 등록 |

키 생성 시 passphrase 설정을 권장한다. **동일한 이름의 키가 이미 있으면 덮어쓰지 않는다.**

```powershell
Get-Content "$HOME\.ssh\study_ed25519.pub"
ssh-keygen -lf "$HOME\.ssh\study_ed25519.pub"
```

출력된 공개키 **한 줄 전체**를 복사한다. 개인키 파일은 복사하거나 공유하지 않는다.

## 4. 원격 PC: 공개키 등록

원격 PC의 로그인 계정이 **관리자 그룹에 속하는지**에 따라 파일 경로가 달라진다. 아래 두 방식 중 하나만 선택한다.

| 접속 계정 | 기본 공개키 등록 파일 |
|---|---|
| 일반 사용자 | `C:\Users\<계정명>\.ssh\authorized_keys` |
| 로컬 Administrators 그룹 사용자 | `C:\ProgramData\ssh\administrators_authorized_keys` |

### 일반 사용자 계정

해당 **접속 대상 계정으로 원격 PC에 로그인한 상태**에서 실행한다.

```powershell
New-Item -ItemType Directory -Force "$HOME\.ssh" | Out-Null
$f = "$HOME\.ssh\authorized_keys"
$key = Read-Host '공개키 한 줄 입력'
Add-Content -Path $f -Value $key -Encoding Ascii
```

### 관리자 그룹 계정

**원격 PC의 관리자 PowerShell**에서 실행한다.

```powershell
$f = "$env:ProgramData\ssh\administrators_authorized_keys"
$key = Read-Host '공개키 한 줄 입력'
Add-Content -Path $f -Value $key -Encoding Ascii

# 관리자 그룹·SYSTEM ACL 부여 (Windows 언어에 독립적인 SID)
icacls.exe $f /inheritance:r /grant:r '*S-1-5-32-544:F' '*S-1-5-18:F'
icacls.exe $f
Restart-Service sshd
```

ACL 출력에 **불필요한 다른 사용자·그룹의 접근 권한이 남아 있다면** 별도로 제거해야 한다. 위 명령의 `/grant:r`은 모든 기존 명시적 권한을 자동으로 삭제하는 명령이 아니다. 권한 설정은 실제 출력을 확인하고 진행한다.

**인코딩 주의:** OpenSSH 공개키 파일은 ASCII 또는 UTF-8 BOM 없음으로 보관한다. Windows PowerShell 5.1에서 `>` 리다이렉션으로 파일을 만들면 UTF-16LE이 될 수 있다. 여기서는 `-Encoding Ascii`를 명시했다. 기존 파일에 다른 인코딩이 섞여 있다면 그대로 덧붙이지 말고 백업 후 정상화한다. 일반적인 CRLF 줄바꿈 자체는 주된 문제가 아니다.

**중복 주의:** 위 `Add-Content` 예시는 실습용이며 재실행하면 같은 키가 중복 등록될 수 있다. 기존 공개키를 확인한 후 추가한다.

## 5. 실제 SSH 공개키 인증 확인

접속할 PC에서 아래 명령을 실행한다.

```powershell
ssh -o IdentitiesOnly=yes -o PasswordAuthentication=no `
  -i "$HOME\.ssh\study_ed25519" <원격계정>@<원격_PC_주소>
```

최초 접속 시 표시되는 **서버 호스트 키 지문**은 원격 PC에서 확인한 값과 대조한다. `PasswordAuthentication=no`는 계정 비밀번호로 우회 접속하는 상황을 피하기 위한 검사다. **개인키 passphrase를 묻는 것은 정상**이다.

접속 후 확인:

```powershell
whoami
hostname
```

이 두 명령이 원격 PC의 정보를 반환하고 로그인에 성공하면 SSH 키 인증 경로를 검증한 것이다.

## 6. 자주 겪는 오류

| 증상 | 먼저 확인할 것 |
|---|---|
| `Connection timed out` | 네트워크·방화벽·주소 |
| `Connection refused` | 원격 `sshd` 실행·포트 |
| `Permission denied (publickey)` | 등록 계정, 키 경로, 공개키 내용, ACL |
| `Host key verification failed` | 호스트 지문 변경 여부. 임의 삭제·수락 금지 |
| `Add-WindowsCapability`의 `Class not registered` | PowerShell 실행 환경·Windows 구성 요소 오류. Windows PowerShell 5.1에서 재확인 |

원격 서버의 SSH 로그(Windows):

```powershell
Get-WinEvent -LogName OpenSSH/Operational -MaxEvents 10 |
  Select-Object TimeCreated, Message
```

SSH 접속 시 CMD가 실행되더라도 이는 키 인증 오류가 아니다. Windows OpenSSH 기본 셸 문제이며, **PowerShell을 사용하고 싶을 때만** 원격 PC에서 `HKLM:\SOFTWARE\OpenSSH`의 `DefaultShell`을 실제 `powershell.exe` 또는 `pwsh.exe` 경로로 설정한다.

## 7. 핵심 정리

**서버 실행 확인 → 포트 연결 확인 → 키 생성 → 계정에 맞게 공개키 등록 → 비밀번호 인증 없이 접속 검증** 순서로 진행한다. 로컬 포트 검사만으로 모든 과정이 끝났다고 판단하면 안 된다.

### 공식 참고 자료

- [Microsoft Learn — Windows OpenSSH 서버 설치](https://learn.microsoft.com/ko-kr/windows-server/administration/openssh/openssh_install_firstuse)
- [Microsoft Learn — 키 기반 인증과 관리자 ACL](https://learn.microsoft.com/ko-kr/windows-server/administration/openssh/openssh_keymanagement)
- [Microsoft Learn — PowerShell 문자 인코딩](https://learn.microsoft.com/ko-kr/powershell/module/microsoft.powershell.core/about/about_character_encoding)
