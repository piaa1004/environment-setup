# PC2,PC3 체크리스트

클로드코드 말고 수동으로 했을때의 커멘드 문서 정리


## 최종 체크리스트 (PowerShell 환경에서 실행)

* [ ] PC1에서 원격 Docker 실행 확인
* [ ] PC2·PC3 절전 모드 해제
* [ ] PC2·PC3 OpenSSH 서버 설치 및 실행
* [ ] SSH 방화벽 설정 (아래 있음)
* [ ] PC2·PC3 Docker Desktop 설치 및 실행
* [ ] IP 주소 DHCP 예약
* [ ] Windows 사용자 계정 및 시스템 사양 확인
* [ ] PC1에서 SSH 접속 테스트
* [ ] SSH 공개 키 인증 설정 (=== 수정 이후 부터 공개키 등록 및 방화벽 허용)

```
$key = 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHakVAViWACnBpVVuGcc4qv6P7FKdN7eg4ZqWK2Loh61 pmart-pc1-ds'
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole('Administrators')
$f = 'C:\ProgramData\ssh\administrators_authorized_keys'
"=== 진단"
"계정: $env:USERNAME / 관리자 그룹: $isAdmin"
"sshd: $((Get-Service sshd).Status) / 시작 유형: $((Get-Service sshd).StartType)"
"키 파일 있음: $(Test-Path $f)"
if (Test-Path $f) { "키 등록됨: $([bool](Select-String -Path $f -SimpleMatch 'pmart-pc1-ds' -Quiet))"; icacls $f }
"ping 규칙: $([bool](Get-NetFirewallRule -Name pmart-icmp -ErrorAction SilentlyContinue))"

"=== 수정"
if (-not (Test-Path $f) -or -not (Select-String -Path $f -SimpleMatch 'pmart-pc1-ds' -Quiet)) { Add-Content -Path $f -Value $key -Encoding ascii; "키 추가함" }
icacls.exe $f /inheritance:r /grant "*S-1-5-32-544:F" /grant "*S-1-5-18:F" | Out-Null; "키 파일 권한 정리함"
if (-not (Get-NetFirewallRule -Name pmart-icmp -ErrorAction SilentlyContinue)) { New-NetFirewallRule -Name pmart-icmp -DisplayName "PMart ping (LAN)" -Protocol ICMPv4 -IcmpType 8 -RemoteAddress 192.168.0.0/24 -Action Allow | Out-Null; "ping 규칙 추가함" }
New-ItemProperty -Path "HKLM:\SOFTWARE\OpenSSH" -Name DefaultShell -Value "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -PropertyType String -Force | Out-Null
Restart-Service sshd; "sshd 재시작함"
```



```
$k = 'ssh-ed25519 ' +
     'AAAAC3NzaC1lZDI1NTE5AAAA' +
     'IELC3CtV0wbOaeAQRIIckVho' +
     'WBfBLJU+Ofyd1JCvj4UL' +
     ' pmart-lan pc1 2026-10-28'
$f = "$env:ProgramData\ssh\administrators_authorized_keys"
Add-Content -Path $f -Value $k -Encoding ascii
icacls $f /inheritance:r /grant "Administrators:F" /grant "SYSTEM:F"
Get-Content $f
```

```
# 절전·최대 절전 해제 (전원 연결 시)
powercfg /change standby-timeout-ac 0; powercfg /change hibernate-timeout-ac 0

# OpenSSH 서버 설치·자동 시작, 기본 셸 PowerShell
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
Set-Service sshd -StartupType Automatic; Start-Service sshd
New-ItemProperty -Path "HKLM:\SOFTWARE\OpenSSH" -Nandows\System32\WindowsPowerShell\v1.0\powershell.exe" -PropertyType String -Force

# 방화벽: LAN에서만 SSH·ping 허용
New-NetFirewallRule -Name pmart-ssh  -DisplayName "PMart SSH (LAN)"  -Protocol TCP -LocalPort 22 -RemoteAddress 192.168.0.0/24 -Action Allow
New-NetFirewallRule -Name pmart-icmp -DisplayName "PMart ping (LAN)" -Protocol ICMPv4 -IcmpType 8 -RemoteAddress 192.168.0.0/24
-Action Allow
ors_authorized_keys'
Add-Content -Path $f -Value 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHakVAViWACnBpVVuGcc4qv6P7FKdN7eg4ZqWK2Loh61 pmart-pc1-ds' -Encoding ascii
icacls.exe $f /inheritance:r /grant "*S-1-5-32-544:F" /grant "*S-1-5-18:F"
Restart-Service sshd
```
