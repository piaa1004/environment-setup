# etc/hosts \(이름 \-\> IP 변환\)

## 0. Linux의 /etc/hosts 파일이란? 

/etc/hosts는 리눅스에서 호스트 이름(Hostname)과 IP 주소를 직접 연결(매핑)해 주는 설정 파일

참고로 Windows의 `hosts` 파일 경로는 다음과 같습니다.

```
C:\Windows\System32\drivers\etc\hosts
```

## 1. 파일 위치와 역할

```
/etc/hosts
```

 리눅스의 최상위 디렉터리인 /(루트) 아래에 etc 디렉터리가 있고, 그 안에 hosts 파일이 존재합니다.

```
/
├── bin/
├── boot/
├── dev/
├── etc/
│   ├── hosts           ← 호스트 이름과 IP 매핑
│   ├── hostname        ← 시스템 호스트 이름
│   └── resolv.conf     ← DNS 서버 설정 관련
├── home/
├── root/
├── usr/
└── var/
```

각 파일의 역할은 다음과 같습니다.

| 파일 | 역할 |
| --- | --- |
| `/etc/hosts` | 호스트 이름과 IP 주소 연결 |
| `/etc/hostname` | 현재 컴퓨터의 호스트 이름 설정 |
| `/etc/resolv.conf` | DNS 이름 해석에 사용하는 설정 |
| `/etc/nsswitch.conf` | hosts 파일과 DNS 등의 조회 순서 설정 |

## 2. `/etc/hosts` 파일 내용

```
127.0.0.1       localhost
127.0.1.1       ubuntu-server

192.168.0.10    pc1
192.168.0.34    pc2
192.168.0.222   pc3
```

위 내용을 정리하면 아래와 같다:

| IP 주소 | 호스트 이름 | 의미 |
| --- | --- | --- |
| `127.0.0.1` | localhost | 자기 자신 |
| `127.0.1.1` | ubuntu-server | 일부 배포판에서 사용하는 로컬 호스트 이름 |
| `192.168.0.10` | pc1 | PC1의 내부 IP |
| `192.168.0.34` | pc2 | PC2의 내부 IP |
| `192.168.0.222` | pc3 | PC3의 내부 IP |

리눅스에서는 IP 대신 호스트 이름으로 접근할 수 있습니다.

```
ssh user@pc2
```

이는 다음 명령어와 같은 IP 주소로 접속을 시도합니다.

```
ssh user@192.168.0.34
```

단, `/etc/hosts`는 IP 주소를 찾는 역할만 하므로 SSH 서버 실행 여부나 방화벽 문제까지 해결하지는 않습니다.


## 3. 전체 변환 과정 (이름 → IP 변환)

1. `ssh user@pc2` 입력
2. `/etc/hosts` 확인 
3. pc2 → `192.168.0.34`
4. `192.168.0.34` 로 SSH 연결 시도

일반적인 리눅스 환경에서 `/etc/nsswitch.conf`에 다음과 같이 설정되어 있다면,

```
hosts: files dns
```

1. `/etc/hosts`에서 호스트 이름 검색
2. 해당 이름이 없으면 DNS 서버에 질의
3. 확인된 IP 주소로 연결 시도

순서로 처리됩니다.
